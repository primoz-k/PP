package si.fri.pp.liki;

import android.content.Context;
import android.view.SurfaceView;

public class Circle extends SurfaceView {
public Circle(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	
}
