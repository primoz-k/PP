package si.fri.pp.liki;
import java.util.ArrayList;
import java.util.Random;

import android.R.bool;
import android.content.Context;  
import android.graphics.Canvas;  
import android.graphics.Color;  
import android.graphics.Paint;   
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;  
import android.widget.Button;

import java.io.Console;
import java.lang.Math;


public class DrawShape extends View {  
	
	   private ArrayList<Point> points;
	   
	   private ArrayList<Point> koti;
	   
	   int stStranicZaNarisat;
	   
	   int width;
	   int height;
	   private Paint paint;       
	   
	   double angle=0;

	   int numberOfangles;
	   
	   int stevec = 0;
	   float tempx = -1;
	   float tempy = -1;
	   int stevecZapisa = 0;
	   boolean preveri = false;
	   int stevecObrata = 0;
	   int score;
	   public DrawShape(Context context) {  
	      super(context);  

	      points = new ArrayList<Point>();
	      koti= new ArrayList<Point>();
	      
	      Random rand = new Random();
	      stStranicZaNarisat = (int)rand.nextInt(7-2) + 2;
	      
	      width = context.getResources().getDisplayMetrics().widthPixels;
	      height = context.getResources().getDisplayMetrics().heightPixels;
	      
	      paint = new Paint();  
	         
	      this.setFocusable(true);  
	      this.requestFocus();  
	   }  
	    
   @Override  
   protected void onDraw(Canvas canvas) {  

	   paint.setStrokeWidth(0);
	   paint.setColor(Color.rgb(214,213,216));
	   for(int i=60;i<canvas.getWidth();i=i+60){
		   canvas.drawLine(i, 0, i, canvas.getHeight(), paint);
		   
	   }
	   for(int i=60;i<canvas.getHeight();i=i+60){
		   canvas.drawLine(0,i,canvas.getWidth(),i, paint);
	   }
	   
	   paint.setColor(Color.BLACK);
	   canvas.drawRect(4, 9, 300, 101, paint);
	   canvas.drawRect(309, 9, 601, 101, paint);
	   paint.setColor(Color.rgb(0,197,255));
	   
	   //button
	   canvas.drawRect(5, 10, 299, 100, paint);
	   canvas.drawRect(310, 10, 600, 100, paint);
	   paint.setColor(Color.WHITE);
	   canvas.drawText("Preveri", 70, 70, paint);
	   canvas.drawText("Po�isti", 370, 70, paint);
	   
	   paint.setColor(Color.BLUE);
	   canvas.drawText(String.format("%d", score), 610, 70, paint);
	   
	   

	   paint.setColor(Color.BLUE);
	   int x =10;
	   int y = 170;
	   if(stStranicZaNarisat<=2){
		   canvas.drawText("Nari�i lik z 0 stranicami (KROG)", x, y, paint);
	   }else if(stStranicZaNarisat==3){
		   canvas.drawText("Nari�i lik z 3 stranicami (TRIKOTNIK)", x, y, paint);
	   }else if(stStranicZaNarisat==4){
		   canvas.drawText("Nari�i lik z 4 stranicami (�TIRIKOTNIK)", x, y, paint);
	   }else if(stStranicZaNarisat==5){
		   canvas.drawText("Nari�i lik z 5 stranicami (PETKOTNIK)", x, y, paint);
	   }else if(stStranicZaNarisat==6){
		   canvas.drawText("Nari�i lik z 6 stranicami (�ESTKOTNIK)", x, y, paint);
	   }

	   paint.setStrokeWidth(10);
	   paint.setColor(Color.GRAY);
	   
	   for(int i = 0; i < points.size()-1; i++) {
			   canvas.drawLine(points.get(i).X, points.get(i).Y, points.get(i+1).X, points.get(i+1).Y, paint);
		   
	   }

	   paint.setTextSize(50);
	   if(stStranicZaNarisat==0 && preveri && numberOfangles<3){
		   paint.setColor(Color.GREEN);
		   canvas.drawText("PRAVILNO!", 500, 100, paint);
		   if(stevecObrata==0){
			   score +=10;
			   stevecObrata++;
		   }
	   }else if(stStranicZaNarisat==numberOfangles &&preveri){
		   paint.setColor(Color.GREEN);
		   canvas.drawText("PRAVILNO!", 500, 100, paint);
		   if(stevecObrata==0){
			   score +=10;
			   stevecObrata++;
		   }
		   
		  
	   }else if(preveri){
		   paint.setColor(Color.RED);
		   canvas.drawText("NAPACNO!", 500, 100, paint);
		   score = 0;

	   }

	      update();  
	      invalidate(); 
   }  
	     
  
   private void update() { 

	   
	   
	  //angle =  Math.toDegrees(Math.acos((((x1-startX)*(x2-startX))+((y1-startY)*(y2-startY)))/(Math.sqrt(Math.pow((x1-startX), 2)+Math.pow((y1-startY), 2))*Math.sqrt(Math.pow((x2-startX), 2)+Math.pow((y2-startY), 2)))));
	  
	   //angle = Math.toDegrees(Math.atan((x1-x2)/(1+x1*x2)));
   }  
   private void reset(){
	   angle =0;
	   tempx = -1;
	   tempy = -1;
	   stevecZapisa = 0;
	   preveri = false;
	   points.clear();
	   koti.clear();
	   numberOfangles = 0;
	   preveri = false;
   }
   
   @Override
	public boolean onTouchEvent(MotionEvent event) {
	   float x = event.getX();
	   float y = event.getY();
	   
	   if(x<610&&x>310&&y<100){
		   reset();
		   
	   }else if(x<300&&y<100){
		   preveri = true;
		   Point prejsnja = null;
		   for(int j=5;j<points.size();j++){
			   if(j>points.size()-5){
				   break;
			   }
			   Point p = points.get(j);
			   boolean found = false;
			   for(int i=0;i<koti.size();i++){
				   Point p1 = koti.get(i);
				   double razdalja = Math.sqrt((p1.X-p.X)*(p1.X-p.X)+(p1.Y-p.Y)*(p1.Y-p.Y));
				   if(p.X==p1.X && p.Y==p1.Y&& razdalja>30){
					   found = true;
				   }
			   }
			  
			   if(!found && p.angle<160 && p.angle>0){
				   double razdalja;
				   if(prejsnja!=null){
					  razdalja = Math.sqrt((prejsnja.X-p.X)*(prejsnja.X-p.X)+(prejsnja.Y-p.Y)*(prejsnja.Y-p.Y));
				   }else{
					   razdalja = 100;
				   }
				   if(razdalja>30){
					   koti.add(p);
				   }
				   prejsnja = p;
			   }
			   
			   
		   }
		   if(stevecZapisa==0){
		   		numberOfangles = koti.size()+1;
		   		stevecZapisa++;
		   		
		   }
		   
	   }else{
		   double razdalja = Math.sqrt((tempx-x)*(tempx-x)+(tempy-y)*(tempy-y));				   
		   if((tempx==-1&&tempy==-1)|| (razdalja<30.0 && razdalja>1.0 &&tempx!=x && tempy!=y)){	
			   boolean find = false;
			   
			   for(Point p: points){
				   if(p.X==x&&p.Y==y){
					  find = true; 
				   }
			   }
			   if(!find){
				   points.add(new Point(x, y));
			   }
		   }
		   tempx =x;
		   tempy =y;
		   if(points.size()>3){
			   for (int i = 1; i < points.size()-1; i++) {
					points.get(i).angle = Math.toDegrees(Math.acos((((points.get(i-1).X-points.get(i).X)*(points.get(i+1).X-points.get(i).X))+((points.get(i-1).Y-points.get(i).Y)*(points.get(i+1).Y-points.get(i).Y)))/(Math.sqrt(Math.pow((points.get(i-1).X-points.get(i).X), 2)+Math.pow((points.get(i-1).Y-points.get(i).Y), 2))*Math.sqrt(Math.pow((points.get(i+1).X-points.get(i).X), 2)+Math.pow((points.get(i+1).Y-points.get(i).Y), 2)))));
					if(i==points.size()-1){
						points.get(0).angle = Math.toDegrees(Math.acos((((points.get(points.size()-1).X-points.get(0).X)*(points.get(1).X-points.get(0).X))+((points.get(points.size()-1).Y-points.get(0).Y)*(points.get(1).Y-points.get(0).Y)))/(Math.sqrt(Math.pow((points.get(points.size()-1).X-points.get(0).X), 2)+Math.pow((points.get(points.size()-1).Y-points.get(0).Y), 2))*Math.sqrt(Math.pow((points.get(1).X-points.get(0).X), 2)+Math.pow((points.get(1).Y-points.get(0).Y), 2)))));
						points.get(points.size()-1).angle = Math.toDegrees(Math.acos((((points.get(points.size()-2).X-points.get(points.size()-1).X)*(points.get(0).X-points.get(points.size()-1).X))+((points.get(points.size()-2).Y-points.get(points.size()-1).Y)*(points.get(0).Y-points.get(points.size()-1).Y)))/(Math.sqrt(Math.pow((points.get(points.size()-2).X-points.get(points.size()-1).X), 2)+Math.pow((points.get(points.size()-2).Y-points.get(points.size()-1).Y), 2))*Math.sqrt(Math.pow((points.get(0).X-points.get(points.size()-1).X), 2)+Math.pow((points.get(0).Y-points.get(points.size()-1).Y), 2)))));
					}
				  }
		    }
	   }
	   
   
	   return true;
	}
}  