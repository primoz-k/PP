package si.fri.pp.liki;

import android.R.color;
import android.graphics.Color;

public class Point {
	 float X; // Center (x,y)  
	 float Y;
	 double angle = 0.0;
	 float memoryX;
	 float memoryY;
	 int color; //if 1 color red else black
	 public Point(float X, float Y) {
		this.X = X;
		this.Y = Y;
		this.memoryX = X;
		this.memoryY = Y;
	}
	 
	 public void setPoint(float x, float y){
		 this.X = x;
		 this.Y = y;
	 }
}
