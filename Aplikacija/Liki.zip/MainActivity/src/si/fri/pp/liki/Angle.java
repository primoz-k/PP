package si.fri.pp.liki;
import java.util.ArrayList;

import android.content.Context;  
import android.graphics.Canvas;  
import android.graphics.Color;  
import android.graphics.Paint;   
import android.view.MotionEvent;
import android.view.View;  
import java.lang.Math;

public class Angle extends View {  
	   
	   int startX=170;
	   int startY=170;
	   int x1 = 300;
	   int x2 = 50;
	   int y1 = 50;
	   int y2 = 300;
	   
	   private ArrayList<Point> points;
	   
	   int width;
	   int height;
	   private Paint paint;       
	   
	   double angle=0;

	   public Angle(Context context) {  
	      super(context);  

	      points = new ArrayList<Point>();
	      
	      // kvadrat
	      
    	  points.add(new Point(100, 400));
    	  points.add(new Point(700, 400));
    	  points.add(new Point(700, 1000));
    	  points.add(new Point(100, 1000));
	      
	      

	      width = context.getResources().getDisplayMetrics().widthPixels;
	      height = context.getResources().getDisplayMetrics().heightPixels;
	     
	      
	      paint = new Paint();  
	         
	      this.setFocusable(true);  
	      this.requestFocus();  
	   }  
	    
   @Override  
   protected void onDraw(Canvas canvas) {  
	   //mreza
	   paint.setStrokeWidth(10);
	   
	   paint.setColor(Color.rgb(128,212,223));
	   canvas.drawText("Notranji koti v likih imajo enako velikost,", 10, 50, paint);
	   canvas.drawText("to lahko doka�emo na spodnjem primeru ", 10, 100, paint);
	   canvas.drawText("kjer premikamo ogli��a kvadrata vsota kotov ", 10, 150, paint);
	   canvas.drawText("pa ostaja 360�!", 10, 200, paint);
	   
	   
	   paint.setTextSize(50);
	   canvas.drawText("Sestevek notranjih kotov: 360�", 100, 300, paint);
	   paint.setColor(Color.GRAY);
	   for(int i = 0; i < points.size(); i++) {
		   
		   if(i==points.size()-1){
			   canvas.drawLine(points.get(i).X, points.get(i).Y, points.get(0).X, points.get(0).Y, paint);
		   }else{
			   canvas.drawLine(points.get(i).X, points.get(i).Y, points.get(i+1).X, points.get(i+1).Y, paint);
		   }
	   }


	   
	   /*canvas.drawLine(startX, startY, x1, y1, paint);
	   canvas.drawLine(startX,startY,x2,y2, paint);*/
	   paint.setTextSize(40);
	   int sumAngles=0;
	   for(Point p: points){
		   sumAngles+=p.angle;
		   paint.setColor(Color.GRAY);
		   canvas.drawText(String.format("%.0f�",p.angle), p.X, p.Y, paint);
		   paint.setColor(Color.RED);
		   canvas.drawCircle(p.X, p.Y, 5, paint);
		   paint.setStyle(Paint.Style.STROKE);
		   paint.setStrokeWidth(5);
		   canvas.drawCircle(p.X, p.Y, 30, paint);
		   paint.setStrokeWidth(1);
		   paint.setStyle(Paint.Style.FILL);
	   }
	    
	   
	      update();  
	      invalidate(); 
   }  
	     
  
   private void update() { 
	  for (int i = 1; i < points.size()-1; i++) {
		points.get(i).angle = Math.toDegrees(Math.acos((((points.get(i-1).X-points.get(i).X)*(points.get(i+1).X-points.get(i).X))+((points.get(i-1).Y-points.get(i).Y)*(points.get(i+1).Y-points.get(i).Y)))/(Math.sqrt(Math.pow((points.get(i-1).X-points.get(i).X), 2)+Math.pow((points.get(i-1).Y-points.get(i).Y), 2))*Math.sqrt(Math.pow((points.get(i+1).X-points.get(i).X), 2)+Math.pow((points.get(i+1).Y-points.get(i).Y), 2)))));
		if(i==1){
			points.get(0).angle = Math.toDegrees(Math.acos((((points.get(points.size()-1).X-points.get(0).X)*(points.get(1).X-points.get(0).X))+((points.get(points.size()-1).Y-points.get(0).Y)*(points.get(1).Y-points.get(0).Y)))/(Math.sqrt(Math.pow((points.get(points.size()-1).X-points.get(0).X), 2)+Math.pow((points.get(points.size()-1).Y-points.get(0).Y), 2))*Math.sqrt(Math.pow((points.get(1).X-points.get(0).X), 2)+Math.pow((points.get(1).Y-points.get(0).Y), 2)))));
			points.get(points.size()-1).angle = Math.toDegrees(Math.acos((((points.get(points.size()-2).X-points.get(points.size()-1).X)*(points.get(0).X-points.get(points.size()-1).X))+((points.get(points.size()-2).Y-points.get(points.size()-1).Y)*(points.get(0).Y-points.get(points.size()-1).Y)))/(Math.sqrt(Math.pow((points.get(points.size()-2).X-points.get(points.size()-1).X), 2)+Math.pow((points.get(points.size()-2).Y-points.get(points.size()-1).Y), 2))*Math.sqrt(Math.pow((points.get(0).X-points.get(points.size()-1).X), 2)+Math.pow((points.get(0).Y-points.get(points.size()-1).Y), 2)))));
		}
	  }
   }  
     
   
   @Override
	public boolean onTouchEvent(MotionEvent event) {
	   float x = event.getX();
	   float y = event.getY();
	   for(Point p:points){
		   float distX = (p.X-x)*(p.X-x);
		   float distY = (p.Y-y)*(p.Y-y);
		 
		   if(Math.sqrt(distX+distY)<150.f){
			   p.X = x-50;
			   p.Y = y-70;
			   if(p.angle > 179.f){
				   p.X = p.memoryX;
				   p.Y = p.memoryY;
			   }
			   for(Point p2:points){
				   for(Point p1:points){
					   if(p1 != p2){
						   float distX1 = (p2.X-p1.X)*(p2.X-p1.X);
						   float distY1 = (p2.Y-p1.Y)*(p2.Y-p1.Y);
						 
						   if(Math.sqrt(distX1+distY1)<0.5){
							   p2.X = p2.memoryX;
							   p2.Y = p2.memoryY;
								
							   p1.X = p1.memoryX;
							   p1.Y = p1.memoryY;
						   }
					   }
				   }
			   }
			   
		   }
	   }
	  
	   
	   
	   return true;
	}
}  