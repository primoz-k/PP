/** Automatically generated file. DO NOT MODIFY */
package si.fri.pp.liki;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}