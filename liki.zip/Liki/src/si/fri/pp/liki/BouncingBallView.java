package si.fri.pp.liki;
import java.util.ArrayList;
import java.util.Random;


import android.R.bool;
import android.content.Context;  
import android.graphics.Canvas;  
import android.graphics.Color;  
import android.graphics.Paint;   

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;  

public class BouncingBallView extends View {  
	   private int xMin = 0;         
	   private int xMax;  
	   private int yMin = 0;  
	   private int yMax;  

	   private int points;
	   private ArrayList<Object> liki;
	   
	   int width;
	   int height;
	   private Paint paint;       
	   
	   private int targetShape; //1=circle, 2=squere, 3=Rect
	   
	   private Boolean napacniZadetek = false; // ce zadenemo napacni lik se postavi na true in izpise text
	   
	   private int numberOfTargets = 0;
 
	   private float faktorHitrostiNaLevel = 1;
	   private Boolean konec = false;
	   
	   private int stevecNovLevel=0;
	   
	   private int level = 1;
	   
	   public BouncingBallView(Context context) {  
	      super(context);  
	      liki = new ArrayList<Object>();
	      Random rand = new Random();
	      
	      targetShape = (int)rand.nextInt(3) + 1;

	      width = context.getResources().getDisplayMetrics().widthPixels;
	      height = context.getResources().getDisplayMetrics().heightPixels;
	      for(int i=0;i<10;i++){
	    	  float x = rand.nextFloat()*(width - 0) + 0;
		      float y = rand.nextFloat()*(height - 0) + 0;
		      float xspeed = (rand.nextFloat()*(10 - 0) + 0)< 5 ? (rand.nextFloat()*(10 - 1) + 1):(rand.nextFloat()*(10 - 1) + 1)*-1;
		      float yspeed = (rand.nextFloat()*(10 - 0) + 0)< 5 ? (rand.nextFloat()*(10 - 1) + 1):(rand.nextFloat()*(10 - 1) + 1)*-1;
		      
	    	  float select = rand.nextFloat()*(300 - 0) + 0;
	    	  
	    	  if(select<100.f){
	    		  liki.add(new Rectangle(x,y,xspeed,yspeed));
	    		  if(targetShape==3){
	    			  numberOfTargets++;
	    		  }
	    	  }else if(select<200.f){
	    		  liki.add(new Ball(x,y,xspeed,yspeed));
	    		  if(targetShape==1){
	    			  numberOfTargets++;
	    		  }
	    	  }else if(select<300.f){
	    		  liki.add(new Squere(x,y,xspeed,yspeed));
	    		  if(targetShape==2){
	    			  numberOfTargets++;
	    		  }
	    	  }
	      }
	      paint = new Paint();  
	         
	      this.setFocusable(true);  
	      this.requestFocus();  
	   }  
	   
	   private void newLevel(){
		   level++;
		   stevecNovLevel = 0;
		   liki.clear();
		   Random rand = new Random();
		      
		      targetShape = (int)rand.nextInt(3) + 1;

		      faktorHitrostiNaLevel+=0.3;
		      for(int i=0;i<10;i++){
		    	  float x = rand.nextFloat()*(width - 0) + 0;
			      float y = rand.nextFloat()*(height - 0) + 0;
			      float xspeed = (rand.nextFloat()*(10 - 0) + 0)< 5 ? (rand.nextFloat()*(10 - 1) + 1):(rand.nextFloat()*(10 - 1) + 1)*-1;
			      float yspeed = (rand.nextFloat()*(10 - 0) + 0)< 5 ? (rand.nextFloat()*(10 - 1) + 1):(rand.nextFloat()*(10 - 1) + 1)*-1;
			      
		    	  float select = rand.nextFloat()*(300 - 0) + 0;
		    	  
		    	  if(select<100.f){
		    		  liki.add(new Rectangle(x,y,xspeed*faktorHitrostiNaLevel,yspeed*faktorHitrostiNaLevel));
		    		  if(targetShape==3){
		    			  numberOfTargets++;
		    		  }
		    	  }else if(select<200.f){
		    		  liki.add(new Ball(x,y,xspeed*faktorHitrostiNaLevel,yspeed*faktorHitrostiNaLevel));
		    		  if(targetShape==1){
		    			  numberOfTargets++;
		    		  }
		    	  }else if(select<300.f){
		    		  liki.add(new Squere(x,y,xspeed*faktorHitrostiNaLevel,yspeed*faktorHitrostiNaLevel));
		    		  if(targetShape==2){
		    			  numberOfTargets++;
		    		  }
		    	  }
		      }
	   }
	    
   @Override  
   protected void onDraw(Canvas canvas) {  
	   //mreza
	   canvas.drawColor(Color.BLACK);
	   paint.setStrokeWidth(0);
	   paint.setColor(Color.GRAY);
	   for(int i=60;i<canvas.getWidth();i=i+60){
		   canvas.drawLine(i, 0, i, canvas.getHeight(), paint);
		   
	   }
	   for(int i=60;i<canvas.getHeight();i=i+60){
		   canvas.drawLine(0,i,canvas.getWidth(),i, paint);
	   }
	   
	  // izris likov 
	   
	   boolean sleep = false;
	   	if(konec){
	    	  try{
	    	  Thread.sleep(100);
	    	  }catch(Exception e){}
		      
	    	  newLevel();
	      }
	   	stevecNovLevel++;
	   	if(stevecNovLevel<50){
	   		paint.setTextSize(width/10);
	    	  paint.setColor(Color.RED);
	   		canvas.drawText("Level"+level, width/2-width/10, height/2-width/10, paint);
	   		konec = false;
	   	}
	   	
		  paint.setStyle(Paint.Style.STROKE);
		  paint.setStrokeWidth(5);
		  paint.setColor(Color.WHITE);
	      for(Object b1:liki){
	    	  if(b1 instanceof Rectangle){
		    	  Rectangle b =(Rectangle)b1;
		    	  if(b.alowDraw){
				      canvas.drawRect(b.Bounds, paint);
		    	  }
			      
	    	  }else if( b1 instanceof Ball){
	    		  Ball b =(Ball)b1;
		    	  if(b.alowDraw){
				      canvas.drawOval(b.Bounds, paint);
		    	  }
			   }else if(b1 instanceof Squere){
				   Squere b =(Squere)b1;
			    	  if(b.alowDraw){
					      canvas.drawRect(b.Bounds, paint);
			    	  }
			   }
	      }
	      	 
	      //IZPIS TOCK
	      paint.setTextSize(50);
	      paint.setStrokeWidth(0);
	      canvas.drawText("Tocke: "+points*100, 50, 50, paint);
	      
	      String ciljaj = targetShape==1?"Kroge": (targetShape==2?"Kvadrate":"Pravokotnike");
	      canvas.drawText("Ciljaj:"+ciljaj, 50, 100, paint);
	      
	      if(napacniZadetek){
		      paint.setColor(Color.RED);
		      canvas.drawText("Napacen lik!", 200, 50, paint);
	      }
	      
	      
	      

	      update();  
	      invalidate(); 
	   }  
	     
  
	   private void update() {  
		   if(numberOfTargets!=0){
			   for(Object b1:liki){
				   if(b1 instanceof Rectangle){
					   Rectangle b =(Rectangle)b1;
				       if(b.alowDraw){
					      b.Move();
					      // trki z stranicami
				      b.checkCollision(xMax, xMin, yMax, yMin);
				   }
			   }else if( b1 instanceof Ball){
				   Ball b =(Ball)b1;
			       if(b.alowDraw){
				      b.Move();
				      // trki z stranicami
				      b.checkCollision(xMax, xMin, yMax, yMin);
				      
				   }
			   }else if(b1 instanceof Squere){
				   Squere b =(Squere)b1;
			       if(b.alowDraw){
				      b.Move();
				      // trki z stranicami
				      b.checkCollision(xMax, xMin, yMax, yMin);
				   }
			   }
		   }
	   }else{
		   konec = true;
	   }
   }  
     
   // Ce se spremeni velikost
   @Override  
   public void onSizeChanged(int w, int h, int oldW, int oldH) {  
	  //nastavimo novo veliksot ekrana
      xMax = w-1;  
      yMax = h-1;  
   }  
   
   @Override
	public boolean onTouchEvent(MotionEvent event) {
	   	float x = event.getX();
	    float y = event.getY();
	    for(Object b1:liki){
		   if (b1 instanceof Rectangle) {
			   Rectangle b =(Rectangle)b1;
			   if(b.alowDraw){
				   float distX = (b.X-x)*(b.X-x);
				   float distY = (b.Y-y)*(b.Y-y);
				 
				   if(Math.sqrt(distX+distY)<b.RadiusX+30.f){
					   b.alowDraw = false;
					   if(targetShape==3){
						   points++;
					   		napacniZadetek = false;
					   		numberOfTargets--;
					   }else{
						   points--;
						   napacniZadetek = true;
					   }
				   }
			   }
		   }else if( b1 instanceof Ball){
			   Ball b =(Ball)b1;
			   if(b.alowDraw){
				   float distX = (b.X-x)*(b.X-x);
				   float distY = (b.Y-y)*(b.Y-y);
				   if(Math.sqrt(distX+distY)<b.Radius+30.f){
					   b.alowDraw = false;
					   if(targetShape==1){
						   points++;
						   napacniZadetek = false;
						   numberOfTargets--;
					   }else{
						   points--;
						   napacniZadetek = true;
					   }
				   }
			   }
		   }else if(b1 instanceof Squere){
			   Squere b =(Squere)b1;
			   if(b.alowDraw){
				   float distX = (b.X-x)*(b.X-x);
				   float distY = (b.Y-y)*(b.Y-y);
				   if(Math.sqrt(distX+distY)<b.Radius+30.f){
					   b.alowDraw = false;
					   if(targetShape==2){
						   points++;
						   napacniZadetek = false;
						   numberOfTargets--;
					   }else{
						   points--;
						   napacniZadetek = true;
					   }
				   }
			   }
		   }
	   }
	   return true;
	}
}  