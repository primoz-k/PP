package si.fri.pp.liki;


import android.graphics.RectF;

public class Ball {
   float Radius = 70; //velikost zokice
   float X; // Center (x,y)  
   float Y;
   float SpeedX; // hitrost (x,y)  
   float SpeedY;  
   RectF Bounds;  
   
   Boolean alowDraw=true;
   
   public Ball(float x,float y,float speedX,float speedY) {
	   Bounds = new RectF(); 
	   this.X = Radius+x;
	   this.Y = Radius+y;
	   this.SpeedX = speedX;
	   this.SpeedY = speedY;
	   Bounds.set(X-Radius, Y-Radius, X+Radius, Y+Radius);  
   }
   public void Move(){
	   Y += SpeedY;  
	   X += SpeedX; 
	   Bounds.set(X-Radius, Y-Radius, X+Radius, Y+Radius);  
   }
   public void checkCollision(int xMax,int xMin,int yMax,int yMin){
	   if (X + Radius > xMax) {  
	         SpeedX = -SpeedX;  
	         X = xMax-Radius;  
	      } else if (X - Radius < xMin) {  
	         SpeedX = -SpeedX;  
	         X = xMin+Radius;  
	      }  
	      if (Y + Radius > yMax) {  
	         SpeedY = -SpeedY;  
	         Y = yMax - Radius;  
	      } else if (Y - Radius < yMin) {  
	         SpeedY = -SpeedY;  
	         Y = yMin + Radius;  
	      }  
   }

}
