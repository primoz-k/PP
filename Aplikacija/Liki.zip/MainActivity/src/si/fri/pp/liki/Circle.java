package si.fri.pp.liki;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class Circle extends SurfaceView {
public Circle(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	
}
