package si.fri.pp.liki;

import android.graphics.RectF;

public class Rectangle {
	   float RadiusX = 70; // velikost
	   float RadiusY = 50;
	   float X; // Center (x,y)  
	   float Y;
	   float SpeedX; // hitrost (x,y)  
	   float SpeedY;  
	   RectF Bounds;      
	   Boolean alowDraw=true;
	   public Rectangle(float x,float y,float speedX,float speedY) {
		   Bounds = new RectF(); 
		   this.X = RadiusX+x;
		   this.Y = RadiusY+y;
		   this.SpeedX = speedX;
		   this.SpeedY = speedY;
		   Bounds.set(X-RadiusX, Y-RadiusY, X+RadiusX, Y+RadiusY);  
	   }
	   public void Move(){
		   Y += SpeedY;  
		   X += SpeedX; 
		   Bounds.set(X-RadiusX, Y-RadiusY, X+RadiusX, Y+RadiusY);   
	   }
	   public void checkCollision(int xMax,int xMin,int yMax,int yMin){
		   if (X + RadiusX > xMax) {  
		         SpeedX = -SpeedX;  
		         X = xMax-RadiusX;  
		      } else if (X - RadiusX < xMin) {  
		         SpeedX = -SpeedX;  
		         X = xMin+RadiusX;  
		      }  
		      if (Y + RadiusY > yMax) {  
		         SpeedY = -SpeedY;  
		         Y = yMax - RadiusY;  
		      } else if (Y - RadiusY < yMin) {  
		         SpeedY = -SpeedY;  
		         Y = yMin + RadiusY;  
		      }  
	   }

}
