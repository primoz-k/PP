package si.fri.pp.liki;

import java.util.Random;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class Ploscina extends Activity {

	TextView vprasanjeTv,tockeTv,formulaTv;
	RadioButton b1,b2,b3;
	String vprasanje;
	Button preveri,naprej;
	ImageView formulaIv;
	double ploscina = 0;
	int tocke = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ploscina);
		
		vprasanjeTv = (TextView)findViewById(R.id.vprasanjeTv);
		tockeTv = (TextView)findViewById(R.id.tockeTv);
		formulaTv = (TextView)findViewById(R.id.formulaTv);
		b1 =(RadioButton)findViewById(R.id.radio0);
		b2 =(RadioButton)findViewById(R.id.radio1);
		b3 =(RadioButton)findViewById(R.id.radio2);
		preveri = (Button)findViewById(R.id.preveriBt);
		naprej = (Button)findViewById(R.id.naprejBt);
		formulaIv = (ImageView)findViewById(R.id.formulaIv);
		
		formulaTv.setTextColor(Color.rgb(128,212,223));
		generateQuestion();
		
		naprej.setEnabled(false);
		
		tockeTv.setText(String.format("Tocke: %d", tocke));
		
		preveri.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(b1.isChecked()){
					b1.setBackgroundColor(Color.GREEN);
					b2.setBackgroundColor(Color.TRANSPARENT);
					b3.setBackgroundColor(Color.TRANSPARENT);
					tocke+=10;
					tockeTv.setText(String.format("Tocke: %d", tocke));
					naprej.setEnabled(true);
					preveri.setEnabled(false);
				}else if(b2.isChecked()){
					b2.setBackgroundColor(Color.RED);
					b1.setBackgroundColor(Color.TRANSPARENT);
					b3.setBackgroundColor(Color.TRANSPARENT);
				}else if(b1.isChecked()){
					b3.setBackgroundColor(Color.RED);
					b1.setBackgroundColor(Color.TRANSPARENT);
					b2.setBackgroundColor(Color.TRANSPARENT);
				}
				
			}
		});
		
		naprej.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				b1.setBackgroundColor(Color.TRANSPARENT);
				b2.setBackgroundColor(Color.TRANSPARENT);
				b3.setBackgroundColor(Color.TRANSPARENT);
				generateQuestion();
				b1.setSelected(false);
				b2.setSelected(false);
				b3.setSelected(false);
				naprej.setEnabled(false);
				preveri.setEnabled(true);
			}
		});
		
		
	}

	private void generateQuestion(){
		Random rnd = new Random();
		int izbira = rnd.nextInt(4);
		if(izbira==0){
			int a = rnd.nextInt(40-1)+1;
			vprasanje = String.format("Kolik�na je plo��ina kvadrata z stranicami dol�ine %dcm?",a);
			ploscina = a*a;
			formulaIv.setBackgroundResource(R.drawable.formula_kvadrat);
			formulaTv.setText("Formula za izracun ploscine kvadrata:");
		}else if(izbira==1){
			int a = rnd.nextInt(40-1)+1;
			int b = rnd.nextInt(40-1)+1;
			vprasanje = String.format("Kolik�na je plo��ina pravokotnika z stranicami dol�ine a= %dcm, b= %dcm?",a,b);
			ploscina = a*b;
			formulaIv.setBackgroundResource(R.drawable.formula_pravokotinik);
			formulaTv.setText("Formula za izracun ploscine pravokotnika:");
		}else if(izbira==2){
			int a = rnd.nextInt(40-1)+1;
			vprasanje = String.format("Kolik�na je plo��ina enakostrani�nega trikotnika z stranicami dol�ine %dcm?",a);
			ploscina = (a*a*Math.sqrt(3))/4;
			formulaIv.setBackgroundResource(R.drawable.formula_trikotnik);
			formulaTv.setText("Formula za izracun ploscine enakostrani�nega trikotnika:");
		}else if(izbira==3){
			int a = rnd.nextInt(40-1)+1;
			vprasanje = String.format("Kolik�na je plo��ina kroga z polmerom dol�ine %dcm?",a);
			ploscina = Math.PI*a*a;
			formulaIv.setBackgroundResource(R.drawable.formula_krog);
			formulaTv.setText("Formula za izracun ploscine kroga:");
		}
		
		vprasanjeTv.setText(vprasanje);
		b1.setText(String.format("%.2fcm", ploscina));
		b2.setText(String.format("%.2fcm", ploscina-(rnd.nextInt(4-1)+1)));
		b3.setText(String.format("%.2fcm", ploscina+(rnd.nextInt(4-1)+1)));
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ploscina, menu);
		return true;
	}

}
